package Day48;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import org.openqa.selenium.interactions.Actions;


public class RevenueCalculator {
	
	public static void main(String args[]) {
		
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.get("https://fitpeo.com");
            driver.manage().window().maximize();
            System.out.println("Navigated to FitPeo Homepage");
            
           
            String homeTitle = driver.getTitle();
            assert homeTitle.contains("FitPeo") : "Homepage title mismatch";
            
            WebElement calculatorLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Revenue Calculator")));
            calculatorLink.click();
            System.out.println("Navigated to Revenue Calculator Page");
            
         
            assert driver.getCurrentUrl().contains("revenue-calculator") : "Failed to navigate to Revenue Calculator Page";
            
            
            WebElement slider = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.css-1sfugkh")));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", slider);
            System.out.println("Scrolled to the slider section");
            
           
            Actions actions = new Actions(driver);
            actions.clickAndHold(slider).moveByOffset(50, 0).release().perform(); // Adjust offset for the slider
            WebElement sliderValue = driver.findElement(By.cssSelector(".MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.css-1sfugkh"));
            assert sliderValue.getAttribute("value").equals("820") : "Slider value is not 820";
            System.out.println("Slider adjusted to 820");
            
           
            WebElement textField = driver.findElement(By.cssSelector("input[type='number'][aria-invalid='false']"));
            textField.clear();
            textField.sendKeys("560");
            textField.sendKeys(Keys.TAB); 
            assert sliderValue.getAttribute("value").equals("560") : "Text field did not update the slider to 560";
            System.out.println("Text field updated to 560");
            
            
            WebElement cptSection = driver.findElement(By.cssSelector("div.MuiBox-root.css-1eynrej > p.MuiTypography-root.MuiTypography-body1"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cptSection);
            
           
            driver.findElement(By.cssSelector("input.PrivateSwitchBase-input.css-1m9pwf3[type='checkbox']")).click();
            driver.findElement(By.xpath("//input[@type='checkbox' and @data-indeterminate='false']")).click();
            driver.findElement(By.xpath("//div[3]//label[1]//span[1]//input[1]")).click();
            driver.findElement(By.xpath("//input[@data-indeterminate='false']")).click();
            System.out.println("CPT codes selected");
            
          
            WebElement reimbursementHeader = driver.findElement(By.xpath("//p[@class='MuiTypography-root MuiTypography-body1 inter css-1bl0tdj']"));
            assert reimbursementHeader.getText().equals("$110700") : "Total reimbursement value mismatch";
            System.out.println("Reimbursement value validated as $110700");
                 
        }
          
	    catch (AssertionError e) 
        {
         System.err.println("Assertion failed: " + e.getMessage());
        } 
        catch (Exception e)
        {
         System.err.println("Error occurred: " + e.getMessage());
        } 
        
        finally {
            driver.quit();
            System.out.println("Test completed and browser closed");
        }
        
	}
	
	

}
